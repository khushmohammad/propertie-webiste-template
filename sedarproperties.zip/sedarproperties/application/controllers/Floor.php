<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Floor extends CI_Controller
{

    public function floor_list(){
       $perpage=10;
       $page=$this->input->get('page', true);
       $page=($page-1)*$perpage;
       
       $search_input=$this->input->get('search_input', true);
       if($search_input!=''){
       
         $this->db->like('floor_name', $search_input);
        
       } 
       $tempdb = clone $this->db;
       $total_row=  $tempdb->from('floor')->count_all_results();
       $this->db->limit($perpage, $page); 
       $this->db->order_by("id", "desc");

       $this->db->join('building','building.id=floor.building_name');

       $this->db->join('block','block.id=floor.block_name');

       $result = $this->db->select('floor.id,floor.floor_name,building.name as building_name,block.name as block_name')->get('floor')->result_array();
      //  $result = $this->db->get('floor')->result_array();
       $data=array();
       $data['floor_data'] = $result;
       $data['total_row'] = $total_row;
       echo  json_encode($data);
   }

   public function create_floor_info(){
         
    $post_data =(array) json_decode(file_get_contents("php://input"));
    
    $result= $this->db->insert( 'floor', $post_data);


   

    
    if($result){
       $message['message']='Succefully Created Floor Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }    
   echo json_encode($message); 
    
}

public function view_floor_by_floor_id(){
  $id=  $this->input->get('id', true);
 if(isset($id)){

 $this->db->where('floor.id',$id);

 $this->db->join('building','building.id=floor.building_name');

 $this->db->join('block','block.id=floor.block_name');

 $result = $this->db->select('floor.id,floor.floor_name,building.name as building_name,block.name as block_name')->get('floor')->row_array();


// $result = $this->db->get('floor')->row_array();
 echo json_encode($result); 

 }  
}

public function update_floor_info(){
        
  $update_data =(array) json_decode(file_get_contents("php://input"));
    
   if(isset($update_data['id'])){
        $id=$update_data['id'];
         unset($update_data['id']); 

       $this->db->where('id', $id);
        $result=$this->db->update('floor', $update_data); 

    if($result){
              $message['message']='Succefully Updated Floor Info';     
           }else{
               $message['message']='An error occurred while inserting data';     
           }
    echo json_encode($message);   

   }   
}

public function delete_floor_info_by_id(){
       $id= $this->input->get('id', true);
   if(isset($id)){
    $this->db->where('id', $id);
    $result=$this->db->delete('floor');
    
     if($result){
       $message['message']='Successfully Deleted Floor Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }
      echo json_encode($message);
       
   }
  }


  public function option()
    {
$building=  $this->input->get('building', true);

$this->db->where('building_name',$building);

$query = $this->db->get('block')->result_array();

 echo json_encode($query);

}

 
   public function building_option(){
  
    $query = $this->db->get('building')->result();

    echo json_encode($query);
  
   }  

   
  
} 
