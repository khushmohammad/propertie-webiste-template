<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Unit extends CI_Controller
{

    public function unit_list(){
       $perpage=10;
       $page=$this->input->get('page', true);
       $page=($page-1)*$perpage;
       
       $search_input=$this->input->get('search_input', true);
       if($search_input!=''){
       
         $this->db->like('unit_name', $search_input);
        
         
         
       } 
       $tempdb = clone $this->db;
       $total_row=  $tempdb->from('unit')->count_all_results();
       $this->db->limit($perpage, $page); 
       $this->db->order_by("id", "desc");




       $this->db->join('block','block.id=unit.block_name');
       $this->db->join('building','building.id=unit.building_name');
$this->db->join('properties','properties.id=unit.properties_name');
       $this->db->join('floor','floor.id=unit.floor_name');

       $result = $this->db->select('unit.id,unit.unit_name,block.name as block_name,building.name as building_name,
       floor.floor_name as floor_name,properties.properties_name as properties_name')->get('unit')->result_array();
      // $result = $this->db->get('unit')->result_array();
       $data=array();
       $data['unit_data'] = $result;
       $data['total_row'] = $total_row;
       echo  json_encode($data);
   }

   public function create_unit_info(){
         
    $post_data =(array) json_decode(file_get_contents("php://input"));
    
    $result= $this->db->insert( 'unit', $post_data);
    if($result){
       $message['message']='Succefully Created unit Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }    
   echo json_encode($message); 
    
}

public function view_unit_by_unit_id(){
  $id=  $this->input->get('id', true);
 if(isset($id)){



 $this->db->where('unit.id',$id);




 $this->db->join('block','block.id=unit.block_name');
 $this->db->join('building','building.id=unit.building_name');
$this->db->join('properties','properties.id=unit.properties_name');
 $this->db->join('floor','floor.id=unit.floor_name');

 $result = $this->db->select('unit.id,unit.unit_name,block.name as block_name,building.name as building_name,
 floor.floor_name as floor_name,properties.properties_name as properties_name')->get('unit')->row_array();

// $result = $this->db->get('unit')->();
 echo json_encode($result); 

 }  
}

public function update_unit_info(){
        
  $update_data =(array) json_decode(file_get_contents("php://input"));
    
   if(isset($update_data['id'])){
        $id=$update_data['id'];
         unset($update_data['id']); 

       $this->db->where('id', $id);
        $result=$this->db->update('unit', $update_data); 

    if($result){
              $message['message']='Succefully Updated unit Info';     
           }else{
               $message['message']='An error occurred while inserting data';     
           }
    echo json_encode($message);   

   }   
}

public function delete_unit_info_by_id(){
       $id= $this->input->get('id', true);
   if(isset($id)){
    $this->db->where('id', $id);
    $result=$this->db->delete('unit');
    
     if($result){
       $message['message']='Successfully Deleted unit Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }
      echo json_encode($message);
       
   }
  }

 

   public function builidng_info(){


  
      $query = $this->db->get('building')->result_array();
  
      echo json_encode($query);
    
     } 
   



   public function block_info(){

      
         $building=  $this->input->get('building_name', true);
         
         $this->db->where('building_name',$building);
         
         $query = $this->db->get('block')->result_array();
         
          echo json_encode($query);
         
         
      }

      public function floor_info() {

         $block_name=  $this->input->get('block_name', true);
         
         $this->db->where('block_name',$block_name);
         
         $query = $this->db->get('floor')->result_array();
         
          echo json_encode($query);

        
      }
      public function properties_info(){


  
         $query = $this->db->get('properties')->result_array();
     
         echo json_encode($query);
       
        } 

      
   }
