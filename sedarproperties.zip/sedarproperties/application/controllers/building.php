
<?php

defined('BASEPATH') OR exit('No direct script access allowed');


   

class Building extends CI_Controller{
  
  

  public function building_list(){
    $perpage=10;
    $page=$this->input->get('page', true);
    $page=($page-1)*$perpage;
    
    $search_input=$this->input->get('search_input', true);
    if($search_input!=''){
    
      $this->db->like('name', $search_input);
     
      
      
    } 
    $tempdb = clone $this->db;
    $total_row=  $tempdb->from('building')->count_all_results();
    $this->db->limit($perpage, $page); 
    $this->db->order_by("id", "desc");
    $result = $this->db->get('building')->result_array();
    $data=array();
    $data['building_data'] = $result;
    $data['total_row'] = $total_row;
    echo  json_encode($data);
}




public function building_data(){

                


//  /* Getting file name */
// $filename = time().$_FILES['file']['name'];
// /* Location */
// $location = './assets/image/';
// $this->load->library('upload', $location);
// /* Upload file */
// move_uploaded_file($_FILES['file']['tmp_name'],$location.$filename);



$mainimage= $_FILES['file']['name'];

$data2 = $_POST['image2'];



  list($type, $data2) = explode(';', $data2);
  list(, $data2)      = explode(',', $data2);

 $data2 = base64_decode($data2);



  $imageName = time().$mainimage;
file_put_contents('assets/image/large/'.$imageName, $data2);

     
       $data = $_POST['img'];
      

       
         list($type, $data) = explode(';', $data);
         list(, $data)      = explode(',', $data);
     
        $data = base64_decode($data);


    
         $imageName = time().$mainimage;
       file_put_contents('assets/image/'.$imageName, $data);
       
       
 $firstname= $_POST['name'];
 $address= $_POST['address'];
 $city= $_POST['city'];
 $code= $_POST['code'];
$image = $imageName;
    $data = array(
        
      'name' => $firstname,
       'image'=> $image,
       'address'=> $address,
       'city'=> $city,
       'code'=>$code
       );
    $result= $this->db->insert('building', $data);




    // $result= $this->db->insert( 'building', $post_data);
 if($result){
    $message['message']='Succefully Created building Info';     
 }else{
     $message['message']='An error occurred while inserting data';     
 }    
echo json_encode($message); 


      }


    
// public function deletefile($id)

// {
//   $this->db->select('*');
//   $this->db->from('building');
//   $id = $this->db->where('id', $id);
   
//   $this->db->delete();
  
// }




public function view_building_by_building_id(){
  $id=  $this->input->get('id', true);
 if(isset($id)){
 $this->db->where('id',$id);
 $result = $this->db->get('building')->row_array();
 echo json_encode($result); 

 }  
}

public function update_building_info(){

  $data2 =$_POST['image2'];
 $data = $_POST['imageupdate'];
 
 $filename = time().'_'.$_FILES['file']['name'];
 
  


 if ($data!=""||$data2!=""){


  /* Location */
  list($type, $data) = explode(';', $data);
  list(, $data)      = explode(',', $data);

 $data = base64_decode($data);



  $imageName = time().$filename;
file_put_contents('assets/image/'.$imageName, $data);

list($type, $data2) = explode(';', $data2);
list(, $data2)      = explode(',', $data2);

$data2 = base64_decode($data2);



$imageName = time().$filename;
file_put_contents('assets/image/large/'.$imageName, $data2);

  
  $image = $imageName;
  if($_POST['old_image']!=''){
     $location = './assets/image/';
    unlink($location. $_POST['old_image']);
    $location2 = './assets/image/large/';
    unlink($location2. $_POST['old_image']);
  }
 }
 else{
  $image = $_POST['old_image'];
 }
 //echo $_POST['old_image']; die;
 $address= $_POST['address'];
 $city= $_POST['city'];
 $code= $_POST['code'];
 $firstname= $_POST['name'];
 $id= $_POST['id'];
    $update_data  = array(        
      'name' => $firstname,
      'image'=> $image,
      'address'=> $address,
      'city'=> $city,
      'code'=>$code
    );
        
  //echo "<pre>";

//print_r($update_data);
  //echo "</pre>";die;
    
   if(isset($id)){
      //  $id=$update_data['id'];
       //  unset($update_data['id']); 

       $this->db->where('id', $id);
        $result=$this->db->update('building', $update_data); 

    if($result){
              $message['message']='Succefully Updated building Info';     
           }else{
               $message['message']='An error occurred while inserting data';     
           }
    echo json_encode($message);   

   }   
}

public function delete_building_info_by_id(){
  
 $id= $this->input->get('id', true);

  $this->db->where('id', $id);

     $this->db->select('image');
   
    $query = $this->db->get_where('building', array('id' => $id))->row();
    
    
     foreach($query as $row){
     

    $path = $_SERVER['DOCUMENT_ROOT'].'/sedarproperties/assets/image/'.$row;
         unlink($path);
         $path2 = $_SERVER['DOCUMENT_ROOT'].'/sedarproperties/assets/image/large/'.$row;
         unlink($path2);
     };

   
     $this->db->where('id', $id);
     
   if(isset($id)){
    
    $result=$this->db->delete('building');
   
     if($result){
       $message['message']='Successfully Deleted building Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }
      echo json_encode($message);
       
   }
  }


  // public function post()
  //   {


  
  //     $imgname=  $_POST['name'];


     

     
  //     $data = $_POST['image'];
     
  //       list($type, $data) = explode(';', $data);
  //       list(, $data)      = explode(',', $data);
     
  //       $data = base64_decode($data);


    
  //       $imageName = time().'.jpg';
  //       file_put_contents('assets/image/'.$imageName, $data);
       
       
       
       
  //       $data = $imageName;
    

  //       $data = array(
  //         'name' => 'khush',
  //         'image' => $data
           
  //          );

  //       $result= $this->db->insert('building', $data);
  //       if($result){
  //          echo "done ";
  //      }else{
  //         echo "not done cheack again";
  //      }    




  }


