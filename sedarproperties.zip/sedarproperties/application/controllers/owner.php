<?php



class Owner extends CI_Controller{
	



    

}
 
