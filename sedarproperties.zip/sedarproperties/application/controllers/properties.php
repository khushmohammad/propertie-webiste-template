<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Properties extends CI_Controller
{

    public function properties_list(){
       $perpage=10;
       $page=$this->input->get('page', true);
       $page=($page-1)*$perpage;
       
       $search_input=$this->input->get('search_input', true);
       if($search_input!=''){
       
         $this->db->like('properties_name', $search_input);
        
         
         
       } 
       $tempdb = clone $this->db;
       $total_row=  $tempdb->from('properties')->count_all_results();
       $this->db->limit($perpage, $page); 
       $this->db->order_by("id", "desc");
       $result = $this->db->get('properties')->result_array();
       $data=array();
       $data['properties_data'] = $result;
       $data['total_row'] = $total_row;
       echo  json_encode($data);
   }

   public function create_properties_info(){
         
    $post_data =(array) json_decode(file_get_contents("php://input"));
    
    $result= $this->db->insert( 'properties', $post_data);
    if($result){
       $message['message']='Succefully Created properties Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }    
   echo json_encode($message); 
    
}

public function view_properties_by_properties_id(){
  $id=  $this->input->get('id', true);
 if(isset($id)){
 $this->db->where('id',$id);
 $result = $this->db->get('properties')->row_array();
 echo json_encode($result); 

 }  
}

public function update_properties_info(){
        
  $update_data =(array) json_decode(file_get_contents("php://input"));
    
   if(isset($update_data['id'])){
        $id=$update_data['id'];
         unset($update_data['id']); 

       $this->db->where('id', $id);
        $result=$this->db->update('properties', $update_data); 

    if($result){
              $message['message']='Succefully Updated properties Info';     
           }else{
               $message['message']='An error occurred while inserting data';     
           }
    echo json_encode($message);   

   }   
}

public function delete_properties_info_by_id(){
       $id= $this->input->get('id', true);
   if(isset($id)){
    $this->db->where('id', $id);
    $result=$this->db->delete('properties');
    
     if($result){
       $message['message']='Successfully Deleted properties Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }
      echo json_encode($message);
       
   }
  }
} 
