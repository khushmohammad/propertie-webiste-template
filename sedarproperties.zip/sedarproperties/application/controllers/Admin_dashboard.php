<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard extends CI_Controller {

//  function total_tenant()
// 	{

//         $query = $this->db->query('SELECT * FROM tenant');
        
//     $r= $query->num_rows();
//          echo json_encode($r);

//     }
    
//     function counterItem()
//     {
//       $query = $this->db->query("SELECT count(*) as sum FROM tenant");
//       $r = $query->row()->sum;
//     //   echo json_encode($r);


// }

public function counterItem(){
  
    
   $result = $this->db->get('tenant')->num_rows();
   echo json_encode($result); 
  
   
}

public function counterfloor(){
  
    
    $result = $this->db->get('floor')->num_rows();
    echo json_encode($result); 
   
    
 }
 public function counterbuilding(){
  
    
   $result = $this->db->get('building')->num_rows();
   echo json_encode($result); 
  
   
}
}
