<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Tenant extends CI_Controller
{

    public function tenant_list(){
       $perpage=10;
       $page=$this->input->get('page', true);
       $page=($page-1)*$perpage;
       
       $search_input=$this->input->get('search_input', true);
       if($search_input!=''){
       
         $this->db->like('tenant.name', $search_input);
        
         
         
       } 
       $tempdb = clone $this->db;
       $total_row=  $tempdb->from('tenant')->count_all_results();
       $this->db->limit($perpage, $page); 
       $this->db->order_by("id", "desc");
       
       $this->db->join('unit','unit.id=tenant.unit');
       $this->db->join('building','building.id=tenant.building');


       $this->db->join('floor','floor.id=tenant.floor');
       $this->db->join('block','block.id=tenant.block');

       $result = $this->db->select('tenant.id,tenant.name,unit.unit_name as unit_name,building.name as building_name,block.name as block_name,,floor.floor_name as floor_name,gender,occupation,dob,contact,email,')->get('tenant')->result_array();
      
       $data=array();
       $data['tenant_data'] = $result;
       $data['total_row'] = $total_row;
       echo  json_encode($data);
   }

   public function create_tenant_info(){
         
    $post_data =(array) json_decode(file_get_contents("php://input"));
    
    $result= $this->db->insert( 'tenant', $post_data);
    if($result){
       $message['message']='Succefully Created tenant Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }    
   echo json_encode($message); 
    
}

public function view_tenant_by_tenant_id(){
  $id=  $this->input->get('id', true);
 if(isset($id)){
 $this->db->where('tenant.id',$id);

 $this->db->join('unit','unit.id=tenant.unit');
 $this->db->join('building','building.id=tenant.building');


 $this->db->join('floor','floor.id=tenant.floor');
 $this->db->join('block','block.id=tenant.block');

 $result = $this->db->select('tenant.id,tenant.name,unit.unit_name as unit_name,building.name as building_name,block.name as 
 block_name,,floor.floor_name as floor_name,gender,occupation,dob,contact,email,')->get('tenant')->row_array();




 //$result = $this->db->get('tenant')->();
 echo json_encode($result); 

 }  
}

public function update_tenant_info(){
        
  $update_data =(array) json_decode(file_get_contents("php://input"));
    
   if(isset($update_data['id'])){
        $id=$update_data['id'];
         unset($update_data['id']); 

       $this->db->where('id', $id);
        $result=$this->db->update('tenant', $update_data); 

    if($result){
              $message['message']='Succefully Updated tenant Info';     
           }else{
               $message['message']='An error occurred while inserting data';     
           }
    echo json_encode($message);   

   }   
}

public function delete_tenant_info_by_id(){
       $id= $this->input->get('id', true);
   if(isset($id)){
    $this->db->where('id', $id);
    $result=$this->db->delete('tenant');
    
     if($result){
       $message['message']='Successfully Deleted tenant Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }
      echo json_encode($message);
       
   }
  }


  public function building_option(){
  
    $query = $this->db->get('building')->result_array();

    echo json_encode($query);
  
   }  
 
   public function block_info(){
  
  $building = $this->input->get('building',true);
  
  $this->db->where('building_name',$building);

  $query = $this->db->get('block')->result_array();


echo json_encode($query);
   }

public function floor_info(){

   $block = $this->input->get('block',true);


   $this->db->where('block_name',$block);
$query = $this->db->get('floor')->result_array();
echo json_encode($query);
}

public function unit_info(){

   $floor = $this->input->get('floor',true);

   $this->db->where('floor_name',$floor);
$query=$this->db->get('unit')->result_array();

echo json_encode($query);


}

} 
