<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Block extends CI_Controller
{

    public function block_list(){
       $perpage=10;
       $page=$this->input->get('page', true);
       $page=($page-1)*$perpage;
       
       $search_input=$this->input->get('search_input', true);
       
       if($search_input!=''){
       
      
         $this->db->like('block.name',$search_input);
       
        
       } 
       $tempdb = clone $this->db;
       $total_row=  $tempdb->from('block')->count_all_results();
       $this->db->limit($perpage, $page); 
       $this->db->order_by("block.id", "desc");
      $this->db->join('building','building.id=block.building_name');

       $result = $this->db->select('block.id,block.name,building.name as building_name')->get('block')->result_array();
       $data=array();
       $data['block_data'] = $result;


      
       $data['total_row'] = $total_row;
       echo  json_encode($data);
   }

   public function create_block_info(){
         
    $post_data =(array) json_decode(file_get_contents("php://input"));
    
    $result= $this->db->insert( 'block', $post_data);
    if($result){
       $message['message']='Succefully Created block Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }    
   echo json_encode($message); 
    
}

public function view_block_by_block_id(){
  $id=  $this->input->get('id', true);
 if(isset($id)){
 $this->db->where('block.id',$id);


 $this->db->join('building','building.id=block.building_name');

       $result = $this->db->select('block.id,block.name,building.name as building_name')->get('block')->row_array();
      


// $result = $this->db->get('block')->row_array();
 echo json_encode($result); 

 }  
}

public function update_block_info(){
        
  $update_data =(array) json_decode(file_get_contents("php://input"));
    
   if(isset($update_data['id'])){
        $id=$update_data['id'];
         unset($update_data['id']); 

       $this->db->where('id', $id);
        $result=$this->db->update('block', $update_data); 

    if($result){
              $message['message']='Succefully Updated block Info';     
           }else{
               $message['message']='An error occurred while inserting data';     
           }
    echo json_encode($message);   

   }   
}

public function delete_block_info_by_id(){
       $id= $this->input->get('id', true);
   if(isset($id)){
    $this->db->where('id', $id);
    $result=$this->db->delete('block');
    
     if($result){
       $message['message']='Successfully Deleted block Info';     
    }else{
        $message['message']='An error occurred while inserting data';     
    }
      echo json_encode($message);
       
   }
  }


  public function option_info(){
  
    $query = $this->db->get('building')->result_array();

    echo json_encode($query);
  
   }  



   public function building_info(){
      $id=  $this->input->get('building', true);
     if(isset($id)){
     $this->db->where('id',$id);
     $result = $this->db->get('building')->result_array();
     echo json_encode($result); 
    
     }  
    }

//    public function building_info( $id){


//       $id =$this->db->where('id', $id);
    
//       $query = $this->db->get('building')->result_array();

//       echo json_encode($query);
  
  
// } 
}
