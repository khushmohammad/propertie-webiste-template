<div class="dash">

<div class="card-columns">
    <div class="card bg-primary">
        <div class="card-body text-center">
           <a class="text-light" href="<?php echo base_url()?>admin/tenant"> <p class="card-text">
                <h4>Total Tenant<br>{{tenant}}</h4>
            </p>
            </a>
        </div>
    </div>
    <div class="card bg-success">
        <div class="card-body text-center">
           <a class="text-light" href="<?php echo base_url()?>admin/floor"> <p class="card-text">
                <h4>Total Floor<br>{{floor}}</h4>
            </p></a>
        </div>
    </div>
    <div class="card bg-danger">
        <div class="card-body text-center">
           <a class="text-light" href="<?php echo base_url()?>admin/building"> <p class="card-text">
                <h4>Total building<br>{{building}}</h4>
            </p></a>
        </div>
    </div>


</div>
</div>
    



















