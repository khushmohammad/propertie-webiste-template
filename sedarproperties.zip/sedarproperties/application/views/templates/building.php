


<div class="row" >
  <div class="col-lg-2">
    <h4>Building Detail</h4>
    
  </div>
  <div class="col-lg-8 mt-12" >
    <div class="input-group col-md-12">
      <input type="text" id="search_input" value="" ng-model="search_input" class="form-control" placeholder="Search" />
      <span class="input-group-btn">
      <button ng-click="bld_ctrl.search_data(search_input)" class="button button-green" type="button"> <span class=" fas fa-search"></span> </button>
      </span> </div>
  </div>
  <div class="col-lg-2 ">
    <button type="button" class="button button-purple mt-12 pull-right fas fa-edit"  data-toggle="modal" data-target="#create_building_info_modal">Insert</button>
  </div>
</div>
<p class="{{bld_ctrl.alert_class}}">{{bld_ctrl.msg}}</p>
<div> 
<table class="table table-striped table-bordered table-sm">
  <thead>
    <tr>
      <th>image</th>
      <th>Name</th>
      <th>Address</th>
      <th>City</th>
      <th>Code</th>
     
      
      <th class="text-right">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr ng-repeat="buildings in bld_ctrl.building_list | orderBy : 'name'">
        <!-- <td>{{buildings.id}}</td> -->
        <td ><img data-toggle="modal" data-target="#view_building_info_modal" ng-click="bld_ctrl.get_building_info(buildings.id)" src="<?php echo base_url();?>assets/image/{{buildings.image}}"  height="75px" width="75px"></td>
      <td>{{buildings.name}}</td>
      <td>{{buildings.address}}</td>
      <td>{{buildings.city}}</td>
      <td>{{buildings.code}}</td>
      
      
      <td class="text-right"><button  type="button" data-toggle="modal"  class="button button-red fas fa-trash" ng-click="bld_ctrl.delete_building_info(buildings.id)"></button>
        <button type="button"  data-toggle="modal" data-target="#edit_building_info_modal"  class="button button-blue fas fa-edit" ng-click="bld_ctrl.edit_building_info(buildings.id)"></button>
        <button type="button"  data-toggle="modal" data-target="#view_building_info_modal"  class="button button-green fas fa-eye" ng-click="bld_ctrl.get_building_info(buildings.id)"></button></td>
    </tr>
  </tbody>
</table>
</div>
<div class="float-right">
  
  <pagination  
  class="pagina"
  
    ng-model="currentPage"
    total-items="total_row"
    max-size="maxSize"  
    boundary-links="true"> </pagination>
</div>
<div class="modal fade" id="create_building_info_modal" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Create building Info</h4>
      </div>
      <div class="modal-body">
        <!-- <form method="post"  id="create_building_info_frm" ng-submit="bld_ctrl.addbuilding(building)" >
          <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" ng-model="building.name" id="name" focus-me="{{shouldBeOpen}}" class="form-control" required maxlength="50">
          </div> -->


        <!-- <div class="form-group"></div>
   
          <input type="submit"  class="button button-green  pull-right"  value="submit"/>
          </div>
                  
              </form> -->


        <form method="post" class="canvas" id="create_building_info_frm" ng-submit='bld_ctrl.upload()'>
          <div class="form-group">
          <label >Name:</label>
            <input type="text" ng-model="bld_ctrl.building.name" id="name" focus-me="{{shouldBeOpen}}"
              class="form-control" required maxlength="50">
          </div>
          <div class="form-group">
            <label >Address:</label>
<input type="text" ng-model="bld_ctrl.building.address" id="address" focus-me="{{shouldBeOpen}}"
  class="form-control" required maxlength="50">
</div>
<div class="form-group">
<label >City:</label>
<input type="text" ng-model="bld_ctrl.building.city" id="city" focus-me="{{shouldBeOpen}}"
  class="form-control" required maxlength="50">
</div>
<div class="form-group">
<label >Code:</label>
<input type="text" ng-model="bld_ctrl.building.code" id="code" focus-me="{{shouldBeOpen}}"
  class="form-control" required maxlength="50">
</div>

          <div class="form-group">
          <label >Image:</label>
            <input type='file' ng-model="bld_ctrl.building.image" accept="image/*" id="mainimage">
          </div>
         
          <div class="cropArea">
          
            <ui-cropper   image="myImage" area-type="rectangle" result-image="myCroppedImage"
              result-image-size='[{w: 200,h: 200},{w: 300,h: 300}]' result-array-image='myArray' ></ui-cropper>
          
          </div>
          </br> <br>
          <!-- <ul style="list-style: none;">
        <li> <div ng-show="myCroppedImage!=null"><img ng-src="{{myCroppedImage}}" src="{{myCroppedImage}}"  name='upload' id='image'   /></div></li>
            
        </ul> -->
          <ul style="list-style: none;">
            <li>
              <div  ><img ng-src="{{myArray[0].dataURI}}" 
                  name='upload' id='image' /></div>
            </li>
            <br><br>

            <li>
              <div ><img ng-src="{{myArray[1].dataURI}}" 
                  name='upload2' id='image2' /></div>
            </li>

          </ul>
          <!-- 
            <ul style="list-style: none;">
<br>

              <li ng-repeat="cropedObject in myArray"> <div><img ng-src="{{cropedObject.dataURI}}"  name='upload' id='image'/></div><br>
                <br></li>
            </ul> -->



           
          <div class="form-group mb-50">
            <input type="submit" class="button button-green   pull-right"  onclick="reloadPage();"  value="submit" />
           
            
          </div>
        </form>
      </div>


      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="edit_building_info_modal" role="dialog">
  <div class="modal-dialog"> 
    
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit building Info || {{bld_ctrl.building_info.name}} </h4>
      </div>
      <div class="modal-body" >
        <form method="post" enctype="multipart/form-data"  id="edit_building_info_frm" name="edit_building_info_frm" ng-submit="bld_ctrl.updatebuilding()">
          <input ng-model="bld_ctrl.building_info.id" type="hidden" />
          <div class="form-group">
            <label >Name:</label>
            <input type="text"  ng-model="bld_ctrl.building_info.name" name="updatename" id="updatename"  class="form-control" required maxlength="50">
          </div>
          <div class="form-group">
            <label >Address :</label>
            <input type="text"  ng-model="bld_ctrl.building_info.address" name="address" id="upaddress"  class="form-control" required maxlength="50">
          </div>
          <div class="form-group">
            <label >City :</label>
            <input type="text"  ng-model="bld_ctrl.building_info.city" name="city" id="upcity"  class="form-control" required maxlength="50">
          </div>
          <div class="form-group">
            <label >Code :</label>
            <input type="text"  ng-model="bld_ctrl.building_info.code" name="code" id="upcode"  class="form-control" required maxlength="50">
          </div>
          
          <div class="form-group">
          <label >image:</label>
              <img src="<?php echo base_url();?>assets/image/{{bld_ctrl.building_info.image}}"  height="100px" width="100px">
               </div>
          

          <div class="form-group">
                  <input type='file' name='updateimage' id='updateimage' > 
          </div>

          <div class="cropArea">
              
            <ui-cropper image="myImage" area-type="rectangle" ng-model="bld_ctrl.building_info.image" result-image="myCroppedImage" result-image-size='[{w: 200,h: 200},{w: 300,h: 300}]' result-array-image='myArray'></ui-cropper>
        </div>
      </br>  <br>
      <!-- <ul style="list-style: none;">
    <li> <div ng-show="myCroppedImage!=null"><img ng-src="{{myCroppedImage}}" src="{{myCroppedImage}}"  name='upload' id='image'   /></div></li>
        
    </ul> -->
    <ul style="list-style: none;">
      <li> <div ng-show="myCroppedImage!=null"><img ng-src="{{myArray[0].dataURI}}"   name='upload' id='updateimg'   /></div></li>
<br><br>

      <li> <div ng-show="myCroppedImage!=null"><img ng-src="{{myArray[1].dataURI}}" name='upload2' id='updateimg2'   /></div></li>
         
     </ul>

    
          <div class="form-group mb-50">
            <input type="submit"  class="button button-green  pull-right" onclick="reloadPage();"   value="Update"/>
            <input type='hidden' value="{{bld_ctrl.building_info.image}}" ng-model="bld_ctrl.building_info.image" name='old_image' id='old_image'>
            <input type='hidden' value="{{bld_ctrl.building_info.id}}" ng-model="bld_ctrl.building_info.id" name='id' id='id'>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="view_building_info_modal" role="dialog">
  <div class="modal-dialog"> 
    
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">building Info </h4>
      </div>
      <div class="modal-body" >
        <div class="form-group">
          <label >Name:</label>
          {{bld_ctrl.view_building_info.name}} </div>
          <div class="form-group">
              <label >Image:</label>
              <img src="<?php echo base_url();?>assets/image/{{bld_ctrl.view_building_info.image}}"  height="200px" width="200px">
               </div>

               <div class="form-group">
          <label >Address:</label>
          {{bld_ctrl.view_building_info.Address}} </div>

          <div class="form-group">
          <label >City:</label>
          {{bld_ctrl.view_building_info.city}} </div>
          <div class="form-group">
          <label >Code:</label>
          {{bld_ctrl.view_building_info.code}} </div>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
