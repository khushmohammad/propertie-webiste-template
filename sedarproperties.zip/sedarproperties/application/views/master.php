<?php include('header.php'); ?>

   
    </div>
<div class="d-flex" id="wrapper">

    <!-- Sidebar -- style="background-color:#10181f;" -->
    <div class="bg border-right" id="sidebar-wrapper" style="background-color:#10181f;" >
      <div class="sidebar-heading"><a href="<?php echo base_url()?>index.php"><img src="<?php echo base_url();?>assets/image/Sedarlogo.png"></a> </div>
      <div class="list-group list-group-flush">
        <a href="<?php echo base_url()?>admin" class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="<?php echo base_url()?>admin/building" class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><i class="fas fa-building"></i> Building detail</a>
        <a href="<?php echo base_url()?>admin/floor" class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><i class="fas fa-home"></i> Floor Information</a>
        <a href="<?php echo base_url()?>admin/unit" class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><i class="fas fa-building"></i> Units</a>

         <a href="<?php echo base_url()?>admin/tenant" class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><i class="fas fa-users"></i> Tenant Detail</a>
        
        <a href="<?php echo base_url()?>admin/owner" class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><i class="fas fa-user-circle" ></i> Owner list</a>
        <a href="<?php echo base_url()?>admin/employee" class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><i class="fas fa-user-clock"></i > Employee List</a>
       

        <li  class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;" data-toggle="collapse" data-target="#service" class="collapsed">
                <a href="#" class="text-light"><i class="fas fa-user-shield"></i> Admin   <i class="fa fa-angle-double-right"></i></a>
            </li>
            <ul class="sub-menu collapse"  id="service">
               <li class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;">
                 <a href="<?php echo base_url()?>admin/properties" class="text-light"><i class="fas fa-house-damage"></i> Property types</a></li>
              
               <li class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><a href="<?php echo base_url()?>admin/block" class="text-light"><i class="fas fa-warehouse"></i> Blocks</a></li>
              
               <li class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><a href="<?php echo base_url()?>admin/Amenities" class="text-light"><i class="fas fa-satellite-dish"></i> Amenities</a></li>
               
               <li class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><a href="<?php echo base_url()?>admin/owner" class="text-light"><i class="fas fa-user-shield"></i> Add Owner</a></li>
                
               <li class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;"><a href="<?php echo base_url()?>admin/floor" class="text-light"><i class="fas fa-home"></i> Floors</a></li>
               <li class="list-group-item list-group-item-action text-light bg" style="background-color:#10181f;">
                 <a href="#" class="text-light"><i class="fas fa-info"></i> Managers Details</a></li>
       
            </ul>










      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg border-bottom" style="background-color:#10181f;">
        <button class="btn btn-dark" id="menu-toggle"><span class="fas fa-bars"></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
           
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Admin
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="#">Setting</a>
                <a class="dropdown-item" href="#">Logout</a>
                
            </li>
            
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
          <ui-view>
        </div>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->



<?php include('footer.php'); ?>
  