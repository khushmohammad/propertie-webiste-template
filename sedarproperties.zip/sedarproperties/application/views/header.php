<!DOCTYPE html>
<html lang="en" ng-app="example_codeenable">

<head>
 
   <title ng-bind-template="sedar | {{title}}"></title>
  
<style>

  </style>
 
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  
  <base href="http://localhost/sedarproperties/"> 

  <!-- our font -->
  
 
  <link href='https://fonts.googleapis.com/css?family=Arial' rel='stylesheet'><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

 <!-- our font files -->
  <!-- our stylesheet -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/simple-sidebar.css'); ?>">
  <link rel="stylesheet" href="<?php echo site_url('assets/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo site_url('assets/css/ui-cropper.css'); ?>">
  <!-- angularjs files -->
 <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.15/angular.js"></script>  
  
 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/angular-ui-router/1.0.3/angular-ui-router.js"></script>
    <script data-require="ui-bootstrap@*" data-semver="0.12.1" src="http://angular-ui.github.io/bootstrap/ui-bootstrap-tpls-0.12.1.min.js"></script>
    <!-- module -->
  <script src="<?php echo site_url('angularjs/app.js'); ?>"></script>

   <!-- your all  controller of js -->
  <script src="<?php echo site_url('angularjs/admin_controller.js'); ?>"></script>
  
  <script src="<?php echo site_url('angularjs/floor_controller.js'); ?>"></script>
  <script src="<?php echo site_url('angularjs/building_controller.js'); ?>"></script>
  <script src="<?php echo site_url('angularjs/owner_controller.js'); ?>"></script>
  
  <script src="<?php echo site_url('angularjs/employee_controller.js'); ?>"></script>
  
  <script src="<?php echo site_url('angularjs/tenant_controller.js'); ?>"></script>
  <script src="<?php echo site_url('angularjs/properties_controller.js'); ?>"></script>
  
  <script src="<?php echo site_url('angularjs/Amenities_controller.js'); ?>"></script>
  
  <script src="<?php echo site_url('angularjs/unit_controller.js'); ?>"></script>
  
  <script src="<?php echo site_url('angularjs/block_controller.js'); ?>"></script>
  
  <link href="<?php echo site_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
  

   
<!-- extra -->

<script src="<?php echo site_url('assets/js/ui-cropper.js'); ?>"></script>

<script src="<?php echo site_url('assets/js/popper.min.js'); ?>"></script>


<script src="<?php echo site_url('assets/js/jquery.min.js'); ?>"></script>



<script src="<?php echo site_url('assets/js/bootstrap.min.js'); ?>"></script>



<!-- 
<link href="https://cdnjs.cloudflare.com/ajax/libs/ng-img-crop/0.3.2/ng-img-crop.css" rel="stylesheet">

<script src="https://cdnjs.cloudflare.com/ajax/libs/ng-img-crop/0.3.2/ng-img-crop.js"></script> -->


<!-- exrtra -->
<script type="text/javascript">
    function reloadPage(){
        location.reload(true);
    }
</script>
  <style>
  .cropArea {
 
   
  height:350px;
}


  </style>
  
</head>
 
    <body>
  

