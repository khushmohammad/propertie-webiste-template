
#CODEIGNITER ANGULARJS MySQL CRUD

<b>Resource:</b> 
1. Angularjs
2. Codeigniter 3
3. MySQL
 


<b>Feature:</b> 
1. Create 
2. Update 
3. View 
4. Delete
5. Search Option
6. Pagination

<a  href="http://dev.techcanvas.org/angularjs-ci-mysql-crud-demo/" target="_blank" >Demo</a>

