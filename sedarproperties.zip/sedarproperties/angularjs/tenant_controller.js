myApp.controller('tenant_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{
    

  
    var vm = this;
  
    $scope.currentPage = 1;
    $scope.maxSize = 3;
    this.search_data = function (search_input) {
        if (search_input.length > 0)
            vm.loadData(1);

    };

    this.loadData = function (page_number) {
        var search_input = document.getElementById("search_input").value;
        $http.get(APP_CONSTANTS.BASE_URL+'/tenant/tenant_list?page=' + page_number + '&search_input=' + search_input).then(function (response) {
            vm.tenant_list = response.data.tenant_data;
            $scope.total_row = response.data.total_row;
            
        });
    };

    $scope.$watch('currentPage + numPerPage', function () {

        vm.loadData($scope.currentPage);

        var begin = (($scope.currentPage - 1) * $scope.numPerPage)
                , end = begin + $scope.numPerPage;


    });

    this.addtenant = function (info) {
        $http.post(APP_CONSTANTS.BASE_URL+'/tenant/create_tenant_info', info).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            document.getElementById("create_tenant_info_frm").reset();
            $('#create_tenant_info_modal').modal('toggle');
            vm.loadData($scope.currentPage);
    
        });
    };


    this.edit_tenant_info = function (id) {
        $http.get(APP_CONSTANTS.BASE_URL+'/tenant/view_tenant_by_tenant_id?id=' + id).then(function (response) {
            vm.tenant_info = response.data;
        });
    };


    this.updatetenant = function () {
        $http.put(APP_CONSTANTS.BASE_URL+'/tenant/update_tenant_info', this.tenant_info).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            $('#edit_tenant_info_modal').modal('toggle');
            vm.loadData($scope.currentPage);
        });
    };


    this.get_tenant_info = function (id) {
        $http.get(APP_CONSTANTS.BASE_URL+'/tenant/view_tenant_by_tenant_id?id=' + id).then(function (response) {
            vm.view_tenant_info = response.data;


        });
    };


    this.delete_tenant_info = function (id) {
        $http.delete(APP_CONSTANTS.BASE_URL+'/tenant/delete_tenant_info_by_id?id=' + id).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            vm.loadData($scope.currentPage);
        });
    };

   

       
       
    this.building_options = function () {
        $http.get(APP_CONSTANTS.BASE_URL+'/tenant/building_option').then(function (response) {
            vm.building_options = response.data;


        });
    };
 this.block_information =function(){


    $http.get(APP_CONSTANTS.BASE_URL+'/tenant/block_info?building='+$scope.tenant.building).then(function(response)
{
vm.block_info =response.data;

           });
     };

     this.floor_information = function(){

        $http.get(APP_CONSTANTS.BASE_URL+'/tenant/floor_info?block='+$scope.tenant.block).then(function(response)
        {
vm.floor_info =response.data;
        });
     };

this.unit_information = function (){

    $http.get(APP_CONSTANTS.BASE_URL+'/tenant/unit_info?floor='+$scope.tenant.floor).then(function(response){

       vm.unit_info =response.data; 
    });
}

});




//

