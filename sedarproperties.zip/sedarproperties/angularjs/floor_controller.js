myApp.controller('floor_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{
    


    var vm = this;
  
    $scope.currentPage = 1;
    $scope.maxSize = 3;
    this.search_data = function (search_input) {
        if (search_input.length > 0)
            vm.loadData(1);

    };

    this.loadData = function (page_number) {
        var search_input = document.getElementById("search_input").value;
        $http.get(APP_CONSTANTS.BASE_URL+'/floor/floor_list?page=' + page_number + '&search_input=' + search_input).then(function (response) {
            vm.floor_list = response.data.floor_data;
            $scope.total_row = response.data.total_row;
            
        });
    };

    $scope.$watch('currentPage + numPerPage', function () {

        vm.loadData($scope.currentPage);

        var begin = (($scope.currentPage - 1) * $scope.numPerPage)
                , end = begin + $scope.numPerPage;


    });

    this.addfloor = function (info) {
        $http.post(APP_CONSTANTS.BASE_URL+'/floor/create_floor_info', info).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            document.getElementById("create_floor_info_frm").reset();
            $('#create_floor_info_modal').modal('toggle');
            vm.loadData($scope.currentPage);
    
        });
    };


    this.edit_floor_info = function (id) {
        $http.get(APP_CONSTANTS.BASE_URL+'/floor/view_floor_by_floor_id?id=' + id).then(function (response) {
            vm.floor_info = response.data;
        });
    };


    this.updatefloor = function () {
        $http.put(APP_CONSTANTS.BASE_URL+'/floor/update_floor_info',this.floor_info).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            $('#edit_floor_info_modal').modal('toggle');
            vm.loadData($scope.currentPage);
        });
    };


    this.get_floor_info = function (id) {
        $http.get(APP_CONSTANTS.BASE_URL+'/floor/view_floor_by_floor_id?id=' + id).then(function (response) {
            vm.view_floor_info = response.data;


        });
    };


    this.delete_floor_info = function (id) {
        $http.delete(APP_CONSTANTS.BASE_URL+'/floor/delete_floor_info_by_id?id=' + id).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            vm.loadData($scope.currentPage);
        });
    };

   
   


        this.option_infor = function (building_name) {
            $http.get(APP_CONSTANTS.BASE_URL+'/floor/option?building='+ building_name).then(function (response) {
                vm.option_info = response.data;
           
    
            });
        };
  



    this.building_options = function () {
        $http.get(APP_CONSTANTS.BASE_URL+'/floor/building_option').then(function (response) {
            vm.building_info = response.data;


        });
    };
     
    

});




//

