myApp.controller('employee_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{


});