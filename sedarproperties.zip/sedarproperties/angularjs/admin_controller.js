myApp.controller('admin_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{
    //total Tenant
 
    $http.get(APP_CONSTANTS.BASE_URL+'/Admin_dashboard/counterItem')
    .then(function (response) 
{$scope.tenant =response.data});

//Total Floor
$http.get(APP_CONSTANTS.BASE_URL+'/Admin_dashboard/counterfloor')
.then(function (response) 
{$scope.floor =response.data});



//total building
$http.get(APP_CONSTANTS.BASE_URL+'/Admin_dashboard/counterbuilding')
.then(function (response) 
{$scope.building =response.data});
    
    
    });