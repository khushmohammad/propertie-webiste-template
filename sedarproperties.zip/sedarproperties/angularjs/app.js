
var myApp = angular.module('example_codeenable',['ui.router', 'ui.bootstrap','uiCropper'])




myApp.constant('APP_CONSTANTS', {
	'BASE_URL': 'http://localhost/sedarproperties',
	
}) ;




myApp.config(function ($stateProvider, $locationProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/');
    $stateProvider
    
    .state('/', {
        url: '/admin',
        templateUrl: 'templates/Admin.php',
        controller: 'admin_controller',
        controllerAs: "adn_ctrl",
      
        resolve: {
            'title': ['$rootScope', function ($rootScope) {
                    $rootScope.title = "floor info";
                }]
        }

    })
    .state('/floor', {
        url: '/admin/floor',
        templateUrl: 'templates/floor.html',
        controller: 'floor_controller',
        controllerAs: "flr_ctrl",
      
        resolve: {
            'title': ['$rootScope', function ($rootScope) {
                    $rootScope.title = "floor info";
                }]
        }

    })

    .state('/owner', {
        url: '/admin/owner',
        templateUrl: 'templates/owner.html',
        controller: 'owner_controller',
        controllerAs: "owr_ctrl",
      
        resolve: {
            'title': ['$rootScope', function ($rootScope) {
                    $rootScope.title = "owner Information";
                }]
        }

    })
    .state('/employee', {
        url: '/admin/employee',
        templateUrl: 'templates/employee.html',
        controller: 'employee_controller',
        controllerAs: "emp_ctrl",
      
        resolve: {
            'title': ['$rootScope', function ($rootScope) {
                    $rootScope.title = "Employee Details";
                }]
        }

    })
            
            .state('/building', {

               
                   
              
            
                url: '/admin/building',
                templateUrl: 'templates/building.php',
                controller: 'building_controller',
                controllerAs: "bld_ctrl",
              
                resolve: {
                    'title': ['$rootScope', function ($rootScope) {
                            $rootScope.title = "Building Details";
                        }]
                }

            })
           
            .state('/tenant', {
                url: '/admin/tenant',
                templateUrl: 'templates/tenant.html',
                controller: 'tenant_controller',
                controllerAs: "tnt_ctrl",
              
                resolve: {
                    'title': ['$rootScope', function ($rootScope) {
                            $rootScope.title = "Tenant Detail";
                        }]
                }

            })

            .state('/properties', {
                url: '/admin/properties',
                templateUrl: 'templates/properties.html',
                controller: 'properties_controller',
                controllerAs: "pro_ctrl",
              
                resolve: {
                    'title': ['$rootScope', function ($rootScope) {
                            $rootScope.title = "Properties type";
                        }]
                }

            })
            
            .state('/block', {
                url: '/admin/block',
                templateUrl: 'templates/block.html',
                controller: 'block_controller',
                controllerAs: "blk_ctrl",
              
                resolve: {
                    'title': ['$rootScope', function ($rootScope) {
                            $rootScope.title = "Block";
                        }]
                }

            })

            .state('/Amenities', {
                url: '/admin/Amenities',
                templateUrl: 'templates/Amenities.html',
                controller: 'Amenities_controller',
                controllerAs: "Ant_ctrl",
              
                resolve: {
                    'title': ['$rootScope', function ($rootScope) {
                            $rootScope.title = "Amenities";
                        }]
                }

            })

            .state('/unit', {
                url: '/admin/unit',
                templateUrl: 'templates/unit.html',
                controller: 'unit_controller',
                controllerAs: "unt_ctrl",
              
                resolve: {
                    'title': ['$rootScope', function ($rootScope) {
                            $rootScope.title = "Unit";
                        }]
                }

            })
           
           
            

           
           
             
            

    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });



    myApp.directive("fileInput", function($parse){  
        return{  
             link: function($scope, element, attrs){  
                  element.on("change", function(event){  
                       var files = event.target.files;  
                       //console.log(files[0].name);  
                       $parse(attrs.fileInput).assign($scope, element[0].files);  
                       $scope.$apply();  
                  });  
             }  
        }  
   });  



});
