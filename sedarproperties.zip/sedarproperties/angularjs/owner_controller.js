myApp.controller('owner_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{





  


  
   




 
      $scope.countries = {
          
              'Maharashtra': ['Pune', 'Mumbai', 'Nagpur', 'Akola'],
              'Madhya Pradesh': ['Indore', 'Bhopal', 'Jabalpur'],
              'Rajasthan': ['Jaipur', 'Ajmer', 'Jodhpur']
      
         
      };
      $scope.GetSelectedCountry = function () {
          $scope.strCountry = document.getElementById("country").value;
      };
      $scope.GetSelectedState = function () {
          $scope.strState = document.getElementById("state").value;
      };
  
  

   });

