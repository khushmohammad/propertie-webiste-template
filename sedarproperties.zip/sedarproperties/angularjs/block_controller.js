myApp.controller('block_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{
  
   
    


   var vm = this;
  
   $scope.currentPage = 1;
   $scope.maxSize = 3;
   this.search_data = function (search_input) {
       if (search_input.length > 0)
           vm.loadData(1);

   };

   this.loadData = function (page_number) {
       var search_input = document.getElementById("search_input").value;
       $http.get(APP_CONSTANTS.BASE_URL+'/block/block_list?page=' + page_number + '&search_input=' + search_input).then(function (response) {
           vm.block_list = response.data.block_data;
           $scope.total_row = response.data.total_row;
           
       });
   };

   $scope.$watch('currentPage + numPerPage', function () {

       vm.loadData($scope.currentPage);

       var begin = (($scope.currentPage - 1) * $scope.numPerPage)
               , end = begin + $scope.numPerPage;


   });

   this.addblock = function (info) {
       $http.post(APP_CONSTANTS.BASE_URL+'/block/create_block_info', info).then(function (response) {
           vm.msg = response.data.message;
           vm.alert_class = 'custom-alert';
           document.getElementById("create_block_info_frm").reset();
           $('#create_block_info_modal').modal('toggle');
           vm.loadData($scope.currentPage);
   
       });
   };


   this.edit_block_info = function (id) {
       $http.get(APP_CONSTANTS.BASE_URL+'/block/view_block_by_block_id?id=' + id).then(function (response) {
           vm.block_info = response.data;
       });
   };


   this.updateblock = function () {
       $http.put(APP_CONSTANTS.BASE_URL+'/block/update_block_info', this.block_info).then(function (response) {
           vm.msg = response.data.message;
           vm.alert_class = 'custom-alert';
           $('#edit_block_info_modal').modal('toggle');
           vm.loadData($scope.currentPage);
       });
   };


   this.get_block_info = function (id) {
       $http.get(APP_CONSTANTS.BASE_URL+'/block/view_block_by_block_id?id=' + id).then(function (response) {
           vm.view_block_info = response.data;


       });
   };


   this.delete_block_info = function (id) {
       $http.delete(APP_CONSTANTS.BASE_URL+'/block/delete_block_info_by_id?id=' + id).then(function (response) {
           vm.msg = response.data.message;
           vm.alert_class = 'custom-alert';
           vm.loadData($scope.currentPage);
       });
   };

  
   this.option_infor = function () {
       $http.get(APP_CONSTANTS.BASE_URL+'/block/option_info').then(function (response) {
           vm.option_info = response.data;


       });
   };

   this.building_infor = function () {
    $http.get(APP_CONSTANTS.BASE_URL+'/block/building_info?building=' +$scope.block.building_name).then(function (response) {
        vm.building_info = response.data;


    });
};

  

   });

