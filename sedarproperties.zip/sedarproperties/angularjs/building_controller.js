myApp.controller('building_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{




  

  $scope.myImage='';
  $scope.myCroppedImage='';
  $scope.$watch('myCroppedImage',function(){
    console.log($scope.myArray);
  });

  var handleFileSelect=function(evt) {
    var file=evt.currentTarget.files[0];
    var reader = new FileReader();
    reader.onload = function (evt) {
      $scope.$apply(function($scope){
        $scope.myImage=evt.target.result;
      });
    };
    reader.readAsDataURL(file);
  };
    angular.element(document.querySelector('#mainimage')).on('change',handleFileSelect);
  
    $scope.myImage='';
    $scope.myCroppedImage='';
    $scope.$watch('myCroppedImage',function(){
      console.log($scope.myArray);
    });
  
    var handleFileSelect=function(evt) {
      var file=evt.currentTarget.files[0];
      var reader = new FileReader();
      reader.onload = function (evt) {
        $scope.$apply(function($scope){
          $scope.myImage=evt.target.result;
        });
      };
      reader.readAsDataURL(file);
    };
      angular.element(document.querySelector('#updateimage')).on('change',handleFileSelect);
      
    

      

  

  var vm = this;
  
  $scope.currentPage = 1;
  $scope.maxSize = 3;
  this.search_data = function (search_input) {
      if (search_input.length > 0)
          vm.loadData(1);

  };

  this.loadData = function (page_number) {
      var search_input = document.getElementById("search_input").value;
      $http.get(APP_CONSTANTS.BASE_URL+'/building/building_list?page=' + page_number + '&search_input=' + search_input).then(function (response) {
          vm.building_list = response.data.building_data;
          $scope.total_row = response.data.total_row;
          
      });
  };

  $scope.$watch('currentPage + numPerPage', function () {

      vm.loadData($scope.currentPage);

      var begin = (($scope.currentPage - 1) * $scope.numPerPage)
              , end = begin + $scope.numPerPage;


  });




    this.upload = function(){

 
        var fd = new FormData();
        var files = document.getElementById('image').src;
        var image2 = document.getElementById('image2').src;
        var mainimage = document.getElementById('mainimage').files[0];
     
        
        var name =document.getElementById('name').value;
        var address =document.getElementById('address').value;

        var city =document.getElementById('city').value;

        var code =document.getElementById('code').value;

        fd.append('name',name);
        fd.append('address',address);
        fd.append('city',city);
        fd.append('code',code);

        fd.append('img',files);
        fd.append('image2',image2);
        fd.append('file',mainimage);
         
         
               $http({
         method: 'post',
         url: 'building/building_data',
        
         data:fd,
         headers: {'Content-Type': undefined},
        }).then(function successCallback(response) { 
          
         
          $scope.response = response.data;

          vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            document.getElementById("create_building_info_frm").reset();
            $('#create_building_info_modal').modal('toggle');
            vm.loadData($scope.currentPage);

            
          
        });
       }



  

       this.delete_building_info = function (id) {
        $http.delete(APP_CONSTANTS.BASE_URL+'/building/deletefile?id=' + id).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            vm.loadData($scope.currentPage);
        });
    };






    this.edit_building_info = function (id) {
      $http.get(APP_CONSTANTS.BASE_URL+'/building/view_building_by_building_id?id=' + id).then(function (response) {
          vm.building_info = response.data;
      });
  };


  this.updatebuilding = function () {

    var fd = new FormData();
    var files = document.getElementById('updateimage').files[0];
    var uimg = document.getElementById('updateimg').src;
    var image2 = document.getElementById('updateimg2').src;
    var name =document.getElementById('updatename').value;

    var address =document.getElementById('upaddress').value;

    var city =document.getElementById('upcity').value;

    var code =document.getElementById('upcode').value;
     var old_image =document.getElementById('old_image').value;
    
     
     var id =document.getElementById('id').value;
    // alert(old_image)
    fd.append('name',name);
    fd.append('address',address);
    fd.append('city',city);
    fd.append('code',code);


    fd.append('imageupdate',uimg);
    fd.append('file',files);
    fd.append('image2',image2);
    fd.append('old_image',old_image);
    fd.append('id',id);
   

    $http({
      method: 'post',
      url: 'building/update_building_info',
     
      data:fd,
      headers: {'Content-Type': undefined},
     }).then(function successCallback(response) { 
      
       $scope.response = response.data;
      
      
       vm.msg = response.data.message;
       vm.alert_class = 'custom-alert';
       
       $('#edit_building_info_modal').modal('toggle')
       vm.loadData($scope.currentPage);
       
     });
     
    //        $http({
    //  method: 'post',
    //  url: APP_CONSTANTS.BASE_URL+'/building/update_building_info',
    
    //  data:fd,
    //  headers: {'Content-Type': undefined},
    // }).then(function successCallback(response) { 
     
    //   $scope.response = response.data;
    // });
   }









      // $http.put(APP_CONSTANTS.BASE_URL+'/building/update_building_info', this.building_info).then(function (response) {
      //     vm.msg = response.data.message;
      //     vm.alert_class = 'custom-alert';
      //     $('#edit_building_info_modal').modal('toggle');
      //     vm.loadData($scope.currentPage);
      // });
  


  this.get_building_info = function (id) {
      $http.get(APP_CONSTANTS.BASE_URL+'/building/view_building_by_building_id?id=' + id).then(function (response) {
          vm.view_building_info = response.data;


      });
  };


  this.delete_building_info = function (id) {
      $http.delete(APP_CONSTANTS.BASE_URL+'/building/delete_building_info_by_id?id=' + id).then(function (response) {
          vm.msg = response.data.message;
          vm.alert_class = 'custom-alert';
          vm.loadData($scope.currentPage);
      });
  };


  // $scope.upload = function(){

  //     var fd = new FormData();
  //     var files = document.getElementById('file').files[0];
  //     fd.append('file',files);
    
  //     // AJAX request
  //     $http({
  //      method: 'post',
  //      url: APP_CONSTANTS.BASE_URL+'/building/do_upload',
  //      data: fd,
  //      headers: {'Content-Type': undefined},
  //     }).then(function successCallback(response) { 
  //       // Store response data
  //       $scope.response = response.data;
  //     });
  //    }
 

      


});