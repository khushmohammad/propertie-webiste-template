myApp.controller('properties_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{
    


    var vm = this;
  
    $scope.currentPage = 1;
    $scope.maxSize = 3;
    this.search_data = function (search_input) {
        if (search_input.length > 0)
            vm.loadData(1);

    };

    this.loadData = function (page_number) {
        var search_input = document.getElementById("search_input").value;
        $http.get(APP_CONSTANTS.BASE_URL+'/properties/properties_list?page=' + page_number + '&search_input=' + search_input).then(function (response) {
            vm.properties_list = response.data.properties_data;
            $scope.total_row = response.data.total_row;
            
        });
    };

    $scope.$watch('currentPage + numPerPage', function () {

        vm.loadData($scope.currentPage);

        var begin = (($scope.currentPage - 1) * $scope.numPerPage)
                , end = begin + $scope.numPerPage;


    });

    this.addproperties = function (info) {
        $http.post(APP_CONSTANTS.BASE_URL+'/properties/create_properties_info', info).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            document.getElementById("create_properties_info_frm").reset();
            $('#create_properties_info_modal').modal('toggle');
            vm.loadData($scope.currentPage);
    
        });
    };


    this.edit_properties_info = function (id) {
        $http.get(APP_CONSTANTS.BASE_URL+'/properties/view_properties_by_properties_id?id=' + id).then(function (response) {
            vm.properties_info = response.data;
        });
    };


    this.updateproperties = function () {
        $http.put(APP_CONSTANTS.BASE_URL+'/properties/update_properties_info', this.properties_info).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            $('#edit_properties_info_modal').modal('toggle');
            vm.loadData($scope.currentPage);
        });
    };


    this.get_properties_info = function (id) {
        $http.get(APP_CONSTANTS.BASE_URL+'/properties/view_properties_by_properties_id?id=' + id).then(function (response) {
            vm.view_properties_info = response.data;


        });
    };


    this.delete_properties_info = function (id) {
        $http.delete(APP_CONSTANTS.BASE_URL+'/properties/delete_properties_info_by_id?id=' + id).then(function (response) {
            vm.msg = response.data.message;
            vm.alert_class = 'custom-alert';
            vm.loadData($scope.currentPage);
        });
    };

   

       
     
    

});




//

