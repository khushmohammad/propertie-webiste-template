myApp.controller('unit_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{
  
  
   var vm = this;
  
   $scope.currentPage = 1;
   $scope.maxSize = 3;
   this.search_data = function (search_input) {
       if (search_input.length > 0)
           vm.loadData(1);

   };

   this.loadData = function (page_number) {
       var search_input = document.getElementById("search_input").value;
       $http.get(APP_CONSTANTS.BASE_URL+'/unit/unit_list?page=' + page_number + '&search_input=' + search_input).then(function (response) {
           vm.unit_list = response.data.unit_data;
           $scope.total_row = response.data.total_row;
           
       });
   };

   $scope.$watch('currentPage + numPerPage', function () {

       vm.loadData($scope.currentPage);

       var begin = (($scope.currentPage - 1) * $scope.numPerPage)
               , end = begin + $scope.numPerPage;


   });

   this.addunit = function (info) {
       $http.post(APP_CONSTANTS.BASE_URL+'/unit/create_unit_info', info).then(function (response) {
           vm.msg = response.data.message;
           vm.alert_class = 'custom-alert';
           document.getElementById("create_unit_info_frm").reset();
           $('#create_unit_info_modal').modal('toggle');
           vm.loadData($scope.currentPage);
   
       });
   };


   this.edit_unit_info = function (id) {
       $http.get(APP_CONSTANTS.BASE_URL+'/unit/view_unit_by_unit_id?id=' + id).then(function (response) {
           vm.unit_info = response.data;
       });
   };


   this.updateunit = function () {
       $http.put(APP_CONSTANTS.BASE_URL+'/unit/update_unit_info', this.unit_info).then(function (response) {
           vm.msg = response.data.message;
           vm.alert_class = 'custom-alert';
           $('#edit_unit_info_modal').modal('toggle');
           vm.loadData($scope.currentPage);
       });
   };


   this.get_unit_info = function (id) {
       $http.get(APP_CONSTANTS.BASE_URL+'/unit/view_unit_by_unit_id?id=' + id).then(function (response) {
           vm.view_unit_info = response.data;


       });
   };


   this.delete_unit_info = function (id) {
       $http.delete(APP_CONSTANTS.BASE_URL+'/unit/delete_unit_info_by_id?id=' + id).then(function (response) {
           vm.msg = response.data.message;
           vm.alert_class = 'custom-alert';
           vm.loadData($scope.currentPage);
       });
   };


  

this.builidng_info = function () {
    $http.get(APP_CONSTANTS.BASE_URL+'/unit/builidng_info').then(function (response) {
        vm.builidng_info = response.data;


    });
};

this.block_information = function () {
    $http.get(APP_CONSTANTS.BASE_URL+'/unit/block_info?building_name='+$scope.unit.building_name).then(function (response) {
        vm.block_info = response.data;


    });
};

this.floor_information = function () {
    $http.get(APP_CONSTANTS.BASE_URL+'/unit/floor_info?block_name='+$scope.unit.block_name).then(function (response) {
        vm.floor_info = response.data;


    });
};

this.properties_information = function () {
    $http.get(APP_CONSTANTS.BASE_URL+'/unit/properties_info').then(function (response) {
        vm.properties_info = response.data;


    });
};


   });

