myApp.controller('Amenities_controller', function ($scope, $state, $http, $location,APP_CONSTANTS)
{


});